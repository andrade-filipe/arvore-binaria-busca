public enum Color {
    RED(true),
    BLACK(false)

    Color()
}
