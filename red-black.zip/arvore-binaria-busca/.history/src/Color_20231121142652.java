public enum Color {
    RED, BLACK
}
