public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private class Node {
        private Key key;
        private Value value;
        private Node left;
        private Node right;
        private Node parent;
        private Color color;
        private int size;

        public Node() {
        }

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public void flipNodeColor(){
            if(this.color.equals(color))
        }
    }

}
