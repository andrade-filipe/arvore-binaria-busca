public enum Color {
    RED, BLACK = 0

}
