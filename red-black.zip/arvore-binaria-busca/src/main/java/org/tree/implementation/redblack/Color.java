package org.tree.implementation.redblack;

public enum Color {
    RED,
    BLACK
}
