public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private class Node {
        private Key key;
        private Value value;
        private Color color;
        private int size;
        private Node left;
        private Node right;
        private Node parent;

        public Node() {
        }

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public void flipNodeColor(){
            if(this.color.equals(Color.RED)){
                this.setColor(Color.BLACK);
            } else {
                this.setColor(Color.RED);
            }
        }

        private void setColor(Color color) {
            this.color = color;
        }
    }
}
