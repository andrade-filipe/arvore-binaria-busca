import java.security.Key;

public class RedBlackVideo<Key extends Comparable<Key>, Value> {

    private class Node {
        private Key key;
        private Value value;
        private Color color;
        private int size;
        private Node left;
        private Node right;
        private Node parent;

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public Node(Key key, Value value, int size, Color color, Node parent) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
            this.parent = parent;
        }

        public void flipColor() {
            setColor(color == Color.RED ? Color.BLACK);
        }

        public void paintRed() {
            this.setColor(Color.RED);
        }

        public void paintBlack() {
            this.setColor(Color.BLACK);
        }

        public boolean isRed() {
            return this.color.equals(Color.RED);
        }

        public boolean isBlack() {
            return this.color.equals(Color.BLACK);
        }

        public Color getParentColor() {
            if (this.parent == null) {
                return Color.BLACK;
            }
            return this.parent.color;
        }

        public Color getUncleColor() {
            if (this.getUncle() == null) {
                return Color.BLACK;
            }
            return this.getUncle().color;
        }

        public Color getGrandfatherColor() {
            if (getGrandfather() == null) {
                return Color.BLACK;
            }
            return getGrandfather().color;
        }

        public Node getUncle() {
            if (getGrandfather().right.equals(this.parent)) {
                return getGrandfather().left;
            } else if (getGrandfather().left.equals(this.parent)) {
                return getGrandfather().right;
            } else {
                return null;
            }
        }

        public Node getGrandfather() {
            return this.parent.parent;
        }

        private void setColor(Color color) {
            this.color = color;
        }
    }

}
