public enum Color {
    RED(true),
    BLACK(false)

    private boolean color

    Color()
}
