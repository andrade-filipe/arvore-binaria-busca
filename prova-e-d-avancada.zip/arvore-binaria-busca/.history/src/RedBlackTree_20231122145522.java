import java.util.ArrayList;

public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private Node root;
    private final ArrayList<Key> LRN_POS_ORDEM = new ArrayList<>();
    private final ArrayList<Key> NLR_PRE_ORDEM = new ArrayList<>();
    private final ArrayList<Key> LNR_IN_ORDEM = new ArrayList<>();

    public RedBlackTree() {
    }

    /*Main Methods*/

    public void put(Key key, Value value){
        if(key.equals(null)){
            throw new IllegalArgumentException("Chave Nula");
        } else if (value.equals(null)){
            throw new IllegalArgumentException("Nó sem Informação");
        }

        root = put(root,key,value);
    }

    private Node put(Node node, Key key, Value value){
        if(isEmpty()){
            return new Node(key, value, 1, Color.BLACK);
        }
        if(itsNewNode(node)){
            return new Node(key,value,1,Color.RED);
        }

        int comparation = key.compareTo(node.key);

        if(comparation < 0){
            node.left = put(node.left, key, value);
        } else if (comparation > 0)
    }

    /*To Better Read Code */

    private boolean isRed(Node node){
        if(node.equals(null)){
            return false;
        }
        return node.color.equals(Color.RED);
    }

    private boolean isBlack(Node node){
        return !isRed(node);
    }

    public boolean isEmpty(){
        return size() == 0;
    }

    public boolean hasRoot(){
        return !isEmpty();
    }

    public int size(){
        return size(root);
    }

    private int size(Node node){
        if(node.equals(null)){
            return 0;
        } else {
            return node.size;
        }
    }

    private boolean itsNewNode(Node node){
        return node.equals(null) && hasRoot();
    }

    private class Node {
        private Key key;
        private Value value;
        private Color color;
        private int size;
        private Node left;
        private Node right;
        private Node parent;

        public Node() {
        }

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public Node(Key key, Value value, int size, Color color, Node parent) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
            this.parent = parent;
        }

        public void flipNodeColor() {
            if (this.color.equals(Color.RED)) {
                this.setColor(Color.BLACK);
            } else {
                this.setColor(Color.RED);
            }
        }

        private void setColor(Color color) {
            this.color = color;
        }
    }
}
