public class Main {
    public static void main(String[] args) {
        RedBlackTree<String, Integer> redBlack = new RedBlackTree<>();
        redBlack.put("A", 1);
        redBlack.put("B", 2);
        redBlack.put("C", 3);
        redBlack.put("D", 4);
        redBlack.put("E", 5);
        redBlack.put("F", 6);
        redBlack.put("G", 7);

        quebraLinha("Travessia");
        redBlack.printTraversal();

        quebraLinha("");

    }

    public static void quebraLinha(String msg) {
        System.out.println();
        System.out.println("**********************************************");
        System.out.println(msg.toUpperCase());
        System.out.println("**********************************************");
    }
}
