public class Main {
    public static void main(String[] args) {
        RedBlackTree<String, Integer> redBlack = new RedBlackTree<>()
    }

    public static void quebraLinha(String msg) {
        System.out.println();
        System.out.println("**********************************************");
        System.out.println(msg.toUpperCase());
        System.out.println("**********************************************");
    }
}
