public enum Color {
    RED(true),
    BLACK(false);

    private boolean colorBoolean;

    Color(boolean colorBoolean){
        this.colorBoolean = colorBoolean;
    }

    public boolean getColorBoolean(){
        return 
    }
}
