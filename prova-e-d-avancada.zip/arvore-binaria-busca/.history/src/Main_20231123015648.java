public class Main {
    public static void main(String[] args) {
        RedBlackTree<String, Integer> redBlack = new RedBlackTree<>();
        redBlack.put("A", 1);
        redBlack.put("B", 1);
        redBlack.put("A", 1);
        redBlack.put("A", 1);
        redBlack.put("A", 1);
        redBlack.put("A", 1);
        redBlack.put("A", 1);

    }

    public static void quebraLinha(String msg) {
        System.out.println();
        System.out.println("**********************************************");
        System.out.println(msg.toUpperCase());
        System.out.println("**********************************************");
    }
}
