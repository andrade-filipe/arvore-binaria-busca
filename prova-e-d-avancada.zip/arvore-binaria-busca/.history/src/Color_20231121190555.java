public enum Color {
    RED(true),
    BLACK;
}
