public class Main {
    public static void main(String[] args) {
        
    }

    public static void quebraLinha(String msg) {
        System.out.println();
        System.out.println("**********************************************");
        System.out.println(msg.toUpperCase());
        System.out.println("**********************************************");
    }
}
