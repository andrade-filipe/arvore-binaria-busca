import java.lang.reflect.Array;
import java.util.ArrayList;

public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private Node root;
    private final ArrayList<Key> LRN_POS_ORDEM = new ArrayList<>();
    private final ArrayList<Key> NLR_PRE_ORDEM = new ArrayList<>();
    private final ArrayList<Key> LNR_IN_ORDEM = new ArrayList<>();
    private ArrayList<Node> parentCache;

    public RedBlackTree() {
    }

    /* Main Methods */

    public void put(Key key, Value value) {
        if (key.equals(null)) {
            throw new IllegalArgumentException("Chave Nula");
        } else if (value.equals(null)) {
            throw new IllegalArgumentException("Nó sem Informação");
        }

        this.root = put(this.root, key, value);
    }

    private Node put(Node node, Key key, Value value) {
        if (isEmpty()) {
            return new Node(key, value, 1, Color.BLACK);
        }
        if (itsNewNode(node)) {
            return new Node(key, value,
                    1, Color.RED, parentCache.get(0));
        }

        int comparation = key.compareTo(node.key);
        parentCache.add(0, node);

        if (comparation < 0) {
            node.left = put(node.left, key, value);
        } else if (comparation > 0) {
            node.right = put(node.right, key, value);
        } else {
            node.value = value;
        }
        return balance(node);
    }

    private Node balance(Node node) {
        if (isTheRoot(node)) {
            node.paintBlack();
            return node;
        } else if (isNotTheRoot(node)){
            if(blackParentCase(node)){
                return node;
            } else if(redParentCase(node)){
                if(checkIfRedUncle(node)){
                    flipFamilyColors(node);
                    return node;
                } else if (checkIfBlackUncle(node)){

                }
            }
        }
    }

    private boolean simpleLeftRotation(Node node){
        if(node.color.equals(Color.RED)
        && node.parent.color.equals(Color.RED)
        && node.parent.equals(node.getGrandfather().left)
        && node.equals(node.parent.left)){
            return true;
        }
        return false;
    }

    private boolean simpleRightRotation(Node node){
        if(node.color.equals(Color.RED)
        && node.parent.color.equals(Color.RED)
        && node.parent.equals(node.getGrandfather().right)
        && node.equals(node.parent.);
    }

    private Node leftLeftCase(Node node){
        node.parent.flipColor();
        node.getGrandfather().flipColor();
        return rightRotation(node.getGrandfather());
    }

    private Node rightRightCase(Node node){
        node.parent.flipColor();
        node.getGrandfather().flipColor();
        return leftRotation(node.getGrandfather());
    }

    private Node leftRightCase(Node node){
        node = leftRotation(node.parent);
        return leftLeftCase(node.getGrandfather());
    }

    private Node rightLeftCase(Node node){
        node = rightRotation(node.parent);
        return rightRightCase(node.getGrandfather());
    }

    private void flipFamilyColors(Node node){
        node.parent.flipColor();
        node.getGrandfather().flipColor();
        node.getUncle().flipColor();

        if(node.getGrandfather().equals(this.root)){
            node.getGrandfather().paintBlack();
        }
    }

    private Node rightRotation(Node node){
        Node leftChild = node.left;
        Node leftRightGrandChild = leftChild.right;

        if(!leftRightGrandChild.equals(null)){
            leftRightGrandChild.parent = node;
        }

        leftChild.right = node;
        node.left = leftRightGrandChild;
        node.parent = leftChild;
        return leftChild;
    }

    private Node leftRotation(Node node){
        Node rightChild = node.right;
        Node rightLeftGrandchild = rightChild.left;

        if(!rightLeftGrandchild.equals(null)){
            rightLeftGrandchild.parent = node;
        }

        rightChild.left = node;
        node.right = rightLeftGrandchild;
        node.parent = rightChild;
        return rightChild;
    }

    /* To Better Read Code */

    private boolean isRed(Node node) {
        if (node.equals(null)) {
            return false;
        }
        return node.color.equals(Color.RED);
    }

    private boolean isBlack(Node node) {
        return !isRed(node);
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public boolean hasRoot() {
        return !isEmpty();
    }

    public int size() {
        return size(root);
    }

    private int size(Node node) {
        if (node.equals(null)) {
            return 0;
        } else {
            return node.size;
        }
    }

    private boolean itsNewNode(Node node) {
        return node.equals(null) && hasRoot();
    }

    private boolean isTheRoot(Node node){
        return node.equals(this.root);
    }

    private boolean isNotTheRoot(Node node){
        return !isTheRoot(node);
    }

    private boolean blackParentCase(Node node){
        return node.getParentColor().equals(Color.BLACK);
    }

    private boolean redParentCase(Node node){
        if(node.getParentColor().equals(Color.RED)){
            return true;
        }
        return false;
    }

    private boolean checkIfRedUncle(Node node){
        if(node.getUncleColor().equals(Color.RED)){
            return true;
        }
        return false;
    }

        private boolean checkIfBlackUncle(Node node){
        if(node.getUncleColor().equals(Color.BLACK)){
            return true;
        }
        return false;
    }
    private class Node {
        private Key key;
        private Value value;
        private Color color;
        private int size;
        private Node left;
        private Node right;
        private Node parent;

        public Node() {
        }

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public Node(Key key, Value value, int size, Color color, Node parent) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
            this.parent = parent;
        }

        public void flipColor() {
            if (this.color.equals(Color.RED)) {
                this.setColor(Color.BLACK);
            } else if (this.color.equals(Color.BLACK)) {
                this.setColor(Color.RED);
            }
        }

        public void paintRed() {
            this.setColor(Color.RED);
        }

        public void paintBlack() {
            this.setColor(Color.BLACK);
        }

        public boolean isRed(){
            return this.color.equals(Color.RED);
        }

        public boolean isBlack(){
            return this.color.equals(Color.BLACK);
        }

        public Color getParentColor(){
            if(this.parent.equals(null)){
                return Color.BLACK;
            }
            return this.parent.color;
        }

        public Color getUncleColor(){
            if(this.getUncle().equals(null)){
                return Color.BLACK;
            }
            return this.getUncle().color;
        }

        public Color getGrandfatherColor(){
            if(getGrandfather().equals(null)){
                return Color.BLACK;
            }
            return getGrandfather().color;
        }

        public Node getUncle(){
            if(getGrandfather().right.equals(this.parent)){
                return getGrandfather().left;
            } else if(getGrandfather().left.equals(this.parent)){
                return getGrandfather().right;
            } else {
                return null;
            }
        }

        public Node getGrandfather(){
            return this.parent.parent;
        }

        private void setColor(Color color) {
            this.color = color;
        }
    }
}
