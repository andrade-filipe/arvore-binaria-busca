public class Main {
    public static void main(String[] args) {
        quebraLinha("A) Permitir a Criação de uma àrvore Red Black \n" +
            "F) Para cada inserção de nó, a arvore deve ser impressa \n" +
            "e o nó mostrar o balanceamento");
        RedBlackTree<String, Integer> BBST = getAvlTree();

        quebraLinha("B) Os métodos para realizar o balanceamento nesse algoritmo são:");
        System.out.println("update() -> atualiza os dados de cada nó \n" +
            "balance() -> verifica se o nó está precisando de balanceamento \n" +
            "leftRotation() -> aplica o algoritmo de rotação para a esquerda \n" +
            "rightRotation() -> aplica o algoritmo de rotação para a direita \n" +
            "OBS: os algortimos de rotação dupla são feitos utilizando a técnica de rotacionar \n" +
            "um filho primeiro e depois rotacionar o nó principal.");

        quebraLinha("D) TRAVESSIA PÓS, PRÉ E IN ORDER");
        BBST.printTraversal();

        quebraLinha("E) Impressão da árvore balanceada com o fator de balanceamento em cada nó");
        BBST.printTree();
    }

    private static RedBlackTree<String, Integer> getAvlTree() {
        RedBlackTree<String, Integer> RBTree = new RedBlackTree<>();
        RBTree.put("A", 1);
        RBTree.put("B", 2);
        RBTree.put("C", 3);
        RBTree.put("D", 4);
        RBTree.put("E", 5);
        RBTree.put("F", 6);
        RBTree.put("G", 7);
        RBTree.put("H", 8);
        RBTree.put("I", 9);
        return RBTree;
    }

    public static void quebraLinha(String msg) {
        System.out.println();
        System.out.println("**********************************************");
        System.out.println(msg.toUpperCase());
        System.out.println("**********************************************");
    }

}
