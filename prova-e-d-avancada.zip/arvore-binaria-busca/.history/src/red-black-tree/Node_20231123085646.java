package red-black-tree;

public class Node {
    
}
