public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private class Node {
        private Key key;
        private Value value;
        Node left

    }

}
