import java.util.ArrayList;

public class RedBlackTree<Key extends Comparable<Key>, Value> {

    private Node root;
    private final ArrayList<Key> LRN_POS_ORDEM = new ArrayList<>();
    private final ArrayList<Key> NLR_PRE_ORDEM = new ArrayList<>();
    private final ArrayList<Key> LNR_IN_ORDEM = new ArrayList<>();

    public RedBlackTree() {
    }

    public void put(Key key, Value value){
        if(key.equals(null)){
            throw new IllegalArgumentException("Chave Nula");
        } else if (value.equals(null)){
            
        }
    }

    private class Node {
        private Key key;
        private Value value;
        private Color color;
        private int size;
        private Node left;
        private Node right;
        private Node parent;

        public Node() {
        }

        public Node(Key key, Value value, int size, Color color) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
        }

        public Node(Key key, Value value, int size, Color color, Node parent) {
            this.key = key;
            this.value = value;
            this.size = size;
            this.color = color;
            this.parent = parent;
        }

        public void flipNodeColor() {
            if (this.color.equals(Color.RED)) {
                this.setColor(Color.BLACK);
            } else {
                this.setColor(Color.RED);
            }
        }

        private void setColor(Color color) {
            this.color = color;
        }
    }
}
