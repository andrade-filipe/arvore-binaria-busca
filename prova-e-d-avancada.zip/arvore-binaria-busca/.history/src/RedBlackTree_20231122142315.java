public class RedBlackTree<Key extends Comparable<Key {

    private class Node {
        private Key key;

    }

}
